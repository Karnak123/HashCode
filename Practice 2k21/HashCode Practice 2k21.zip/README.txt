The script files may not reproduce the same result, but may reproduce similar result as the combination generation is randomized.

The below given lines indicate the input files as a-e, and threshold parameter and second_chance_percentage parameter as t and s respectively.
a,b,c -> t = 100000 & s = 0.1
d,e   -> t = 0 & s = 1